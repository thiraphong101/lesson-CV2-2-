# road-lane-detection

Preliminary attempt at automatic lane detection/following algorithm using Python and OpenCV. 

Code largely derived from: 
https://medium.com/pharos-production/road-lane-recognition-with-opencv-and-ios-a892a3ab635c
and
https://github.com/naokishibuya/car-finding-lane-lines

Code processes testvideo2.mp4 file.






