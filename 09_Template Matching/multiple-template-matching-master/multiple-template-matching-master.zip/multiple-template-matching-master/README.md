# multiple-template-matching
an example code for multiple template matching using opencv python
