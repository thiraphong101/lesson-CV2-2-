# Coin-Segmentation
Coin Segmentation : Python OpenCV
